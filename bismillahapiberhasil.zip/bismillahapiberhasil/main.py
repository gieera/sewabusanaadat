# main.py
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List

app = FastAPI()

class Busana(BaseModel):
    nama: str
    harga: str
    region: str
    rating: float
    deskripsi: str
    stok: int
    ukuran: List[str]

busana_adat = [
    Busana(nama="Ulos", harga="500000", region="Sumatera Utara", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Baju Bodo", harga="700000", region="Sulawesi Selatan", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kebaya", harga="800000", region="Jawa Barat", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Ulee Balang", harga="50000", region="Sumatera Selatan", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Ulos", harga="60000", region="Sumatera Barat", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Baju Kurung Basiba", harga="70000", region="Sumatera Utara", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kebaya Laboh", harga="100000", region="Sumatera Selatan", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kurung Cekak Musang", harga="250000", region="Sumatera Barat", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Teluk Belanga", harga="500000", region="Sumatera Utara", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Rejang Lebong", harga="700000", region="Sumatera Selatan", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Baju Kurung Tanggung", harga="800000", region="Sumatera Barat", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Tulang Bawang", harga="50000", region="Sumatera Utara", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Aesan Gede", harga="60000", region="Sumatera Selatan", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Paksian", harga="70000", region="Sumatera Barat", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Baju Pangsi", harga="100000", region="Jawa Barat", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kebaya Encim", harga="250000", region="Jawa Timur", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kebaya Sunda", harga="60000", region="Jawa Barat", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kesatrian Ageng", harga="70000", region="Jawa Tengah", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Pesaan", harga="100000", region="Jawa Tengah", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="King Bibinge", harga="250000", region="Kalimantan Barat", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="King Baba", harga="60000", region="Kalimantan Timur", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Kustin", harga="70000", region="Kalimantan Utara", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Bagajah Gamuling Baulur Lulut", harga="100000", region="Kalimantan Selatan", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Biliu", harga="250000", region="Sulawesi Utara", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Makuta", harga="60000", region="Sulawesi Barat", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Pattuqduq Towain", harga="70000", region="Sulawesi Selatan", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Baju Nggembe", harga="100000", region="Sulawesi Tengah", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Laku Tepu", harga="250000", region="Sulawesi Tenggara", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Payas Agung", harga="60000", region="Bali", rating=4.5, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Amarasi", harga="70000", region="Nusa Tenggara Timur (NTT)", rating=4.7, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Pegon", harga="100000", region="Nusa Tenggara Barat (NTB)", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Cele", harga="250000", region="Maluku", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
    Busana(nama="Seting", harga="250000", region="Bangka Belitung", rating=4.8, deskripsi="Pakaian adat Indonesia adalah salah satu kebudayaan yang perlu dilestarikan. Baju adat menjadi ciri khas tiap daerah sekaligus menumbuhkan kecintaan pada tanah air. ", stok=15, ukuran=["S","M","L"]),
  
]

@app.get("/busana", response_model=List[Busana])
def get_busana(region: str = None):
    if region:
        return [busana for busana in busana_adat if busana.region == region]
  
    return busana_adat